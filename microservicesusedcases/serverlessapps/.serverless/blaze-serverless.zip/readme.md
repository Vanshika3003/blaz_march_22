# Serverless

1. Run the code w/o provisioning or managing infrastructure
    - Upload the code and ask the cloud to execute it
    - Pay for the processing time only
    - Execute the code based on events and scale the code as per the need implicitly
    - Optimize the execution time and performance
        - CPU Utilization
        - Memory Utilization
2. Need for Apps
    - Run the code on event/trigger
    - Perform the Operation
3. AWS Lambda
    - Configure the deployment
    - Inform the AWS about the Runtime Stack
        - The execution Engine
            - Node.js, JRE, .NET, ect.             
4. Cases / Events those are generally used for developing Serverless app
    - Client App (React/Angular/Vuew/JSP/ASP.NET Core/Mobile App) ---> Upload File in S3 ---> Trigger the Lambda ---> The Serverless Function is executed to process the file behind the scene            
    - Sender send Message to Queue --> Trigger is executed when message in Queue --> Lambda Function Read the Message and Process it internally
    - Inter Backup of data

5. serverless-http
    - An event package to listen the HTTP request
    - Used to deploy the REST API as a Lambda or use Lambda as a REST API
    - Create serverless.yml file for deployment configuration
    - npm install -g serverless-http
    - npm install --save aws-sdk serverless-http express    